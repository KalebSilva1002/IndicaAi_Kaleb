# Footer (Rodape) responsivo com html e css
Design de um footer(Rodapé) com icones das redes socias simples feito com html e css usando visual studio code como editor de códico e também foi integrado com o fontawesome!
## [🛠Assistir](https://www.youtube.com/watch?v=zlVJHHDbtQY)
## [⚠Me Ajude](https://www.youtube.com/channel/UCxKIsX5OXyyNWVmomuDc-LA?sub_confirmation=1)
# Preview
![footer-html-css--Rodapé-responsivo(Responsive-Footer)--HTML-e-CSS](/footer-html-css--Rodapé-responsivo(Responsive-Footer)--HTML-e-CSS.png)
